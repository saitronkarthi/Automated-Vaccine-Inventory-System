from flask import Flask,render_template,request,json,jsonify
from twilio.rest import TwilioRestClient
from email.mime.text import MIMEText
import pymysql
import smtplib
import time
import string



hostname = 'xxx'
username = 'xx'
password = 'xxx'
database = 'xxx'
myConnection = pymysql.connect( host=hostname, user=username, passwd=password, db=database )

app = Flask(__name__)


@app.route('/',methods=['GET', 'POST'])
def login():
    if request.method== 'GET':
         return render_template ("login.html")
    if request.method== 'POST':
        count=0
        username= request.form['inputEmail']
        pwd= request.form['inputPassword']
        results=[]
        cur = myConnection.cursor()
        cur.callproc('login_check',(username,pwd))
        resultset=cur.fetchall()
        for row in resultset:
         if row[0]>0:
             count=count+1
        #return str(resultset)
        #return str(count)
        if count>0:
            # query="select * from VendorMaster"
            # cur.execute(query)
            # result = cur.fetchall()
            # for res in result:
            #     results.append(res)
            # print str(results)
            #return render_template('Dashboard.html', dbdis='inherit',Weight=0,dis='none', lvdisp='none', idis='none', lidis='none',sdis='none', lsdis='none', mdis='none', lmdis='none',odis='none',lodis='none')
            #Dashboard();
            resultsitem = []
            cur = myConnection.cursor()
            cur.callproc('sp_OrderCount')
            myConnection.commit()
            resultitem = cur.fetchall()
            for res in resultitem:
                resultsitem.append(res)
            print resultsitem
            if cur.rowcount>0:
                neworders = resultsitem[0][0]
                recorders = resultsitem[1][0]
                autoorders = resultsitem[2][0]
                dashorders = resultsitem[3][0]
            else:
                neworders = 0
                recorders = 0
                autoorders = 0
                dashorders = 0
            return render_template('Dashboard.html', lpddis='none',pddis='none',oddis='none',dbdis='inherit', dis='none', lvdisp='none', idis='none',
                                   lidis='none', mdis='none',
                                   lmdis='none', odis='none', lodis='none', sdis='none', lsdis='none', Weight=0,
                                   neworders=neworders,dbtndis='none', ldbtndis='none',
                                   recorders=recorders, autoorders=autoorders, dashorders=dashorders)
        else:
             return "Not Autorised"+username
        return username+pwd


@app.route('/showVendor/<vid>',methods=['GET', 'POST'])
def showVendor(vid):
    vendorval = vid
    if vendorval == "0":

        query = "select * from VendorMaster order by VendorId DESC "
        results = []
        cur = myConnection.cursor()
        cur.execute(query)
        result = cur.fetchall()
        for res in result:
            results.append(res)
        cur.close()
        return render_template('Dashboard.html',lpddis='none',pddis='none',oddis='none',dbtndis='none', ldbtndis='none',dbdis='none',Weight=0, dis='inherit', lvdisp='none', idis='none', lidis='none',mdis='none',sdis='none', lsdis='none', lmdis='none', odis='none',lodis='none',Vendors=results)
    else:
        query = "select * from VendorMaster where VendorId= "+vendorval
        results = []
        cur = myConnection.cursor()
        cur.execute(query)
        result = cur.fetchall()
        print result
        for res in result:
            results.append(res)
            myjson=str(res[0])+ ','+str(res[1])+ ','+str(res[2])+ ','+str(res[3])+ ','+str(res[4])+','+str(res[5])
        return myjson

@app.route('/showItem/<iid>',methods=['GET', 'POST'])
def showItem(iid):

    itemval=iid
    if itemval == "0":

     query = "select * from ItemMaster order by ItemId DESC "
     results = []
     cur = myConnection.cursor()
     cur.execute(query)
     result = cur.fetchall()
     for res in result:
        results.append(res)
     cur.close()
     # server = smtplib.SMTP('smtp.gmail.com', 587)
     # server.starttls()
     # server.login("meenaramsan@gmail.com", "mks198005")
     #
     # msg = "Python test!"
     # server.sendmail("karcons@gmail.com", "meenaramsan@gmail.com", msg)
     # server.quit()
     return render_template('Dashboard.html',lpddis='none',pddis='none', oddis='none',dbtndis='none', ldbtndis='none',dbdis='none',Weight=0,dis='none', lvdisp='none', idis='inherit', lidis='none', mdis='none', lmdis='none',sdis='none', lsdis='none',odis='none',lodis='none', Items=results)
    else:
        query = "select * from ItemMaster where ItemId= "+itemval
        results = []
        cur = myConnection.cursor()
        cur.execute(query)
        result = cur.fetchall()
        for res in result:
            results.append(res)
            myjson=str(res[0])+ ','+str(res[1])+ ','+str(res[2])+ ','+str(res[3])+ ','+str(res[4])
        return myjson

        # return json.dumps({"Item":results})


@app.route('/showMachine/<mid>',methods=['GET', 'POST'])
def showMachine(mid):
    macval = mid
    if macval == "0":
        query = "select MachineId,Machinecode,Machinedesc from MachineMaster order by MachineId DESC "
        results = []
        cur = myConnection.cursor()
        cur.execute(query)
        result = cur.fetchall()
        for res in result:
            results.append(res)
        return render_template('Dashboard.html',lpddis='none',pddis='none',oddis='none',dbtndis='none', ldbtndis='none',dbdis='none',Weight=0, dis='none', lvdisp='none', idis='none', lidis='none', mdis='inherit',sdis='none', lsdis='none', lmdis='none', odis='none',lodis='none',Machines=results)
    else:
        query = "select * from MachineMaster where MachineId= " + macval
        results = []
        cur = myConnection.cursor()
        cur.execute(query)
        result = cur.fetchall()
        for res in result:
            results.append(res)
            myjson = str(res[0]) + ',' + str(res[1]) + ',' + str(res[2])
        return myjson


@app.route('/vendor', methods=['GET','POST'])
def vendor():
    if request.method == 'POST':
        results=[]
        cur = myConnection.cursor()
        # data=request.get_json('data')
        vid = request.form['txtVendorId']
        vcode= request.form['txtVendorCode']
        vname=request.form['txtVendorName']
        address =request.form['txtVendorAddress']
        email = request.form['txtVendorEmail']
        phone =request.form['txtVendorPhone']
        cur.callproc('sp_InsertVendor',(vid, vcode, vname, address, email, phone))
        myConnection.commit()
        query = "select * from VendorMaster order by VendorId DESC "
        cur.execute(query)
        result = cur.fetchall()
        for res in result:
            results.append(res)
        return render_template('Dashboard.html',lpddis='none',pddis='none',oddis='none',dbtndis='none', ldbtndis='none',dbdis='none',Weight=0, dis='inherit', lvdisp='inherit', idis='none', lidis='none',mdis='none',sdis='none', lsdis='none', lmdis='none',odis='none',lodis='none', Vendors=results)




@app.route('/item', methods=['GET','POST'])
def item():
    if request.method == 'POST':
        results=[]
        cur = myConnection.cursor()
        iid = request.form['txtItemId']
        icode= request.form['txtItemCode']
        iname=request.form['txtItemName']
        idesc =request.form['txtItemDesc']
        iunit = request.form['txtItemUnit']
        cur.callproc('sp_InsertItem',(iid, icode, iname, idesc, iunit))
        myConnection.commit()
        query = "select * from ItemMaster order by ItemId DESC "
        cur.execute(query)
        result = cur.fetchall()
        for res in result:
            results.append(res)

        return render_template('Dashboard.html',lpddis='none',pddis='none',oddis='none',dbtndis='none', ldbtndis='none',Weight=0,dbdis='none', dis='none', lvdisp='none', idis='inherit', lidis='inherit',mdis='none', lmdis='none',odis='none',lodis='none',sdis='none', lsdis='none', Items=results)


@app.route('/machine', methods=['GET','POST'])
def machine():
    if request.method == 'POST':
        results=[]
        cur = myConnection.cursor()
        mid = request.form['txtMachineId']
        mcode= request.form['txtMachineCode']
        mdesc =request.form['txtMachineDesc']
        cur.callproc('sp_InsertMachine',(mid, mcode, mdesc))
        myConnection.commit()
        query = "select * from MachineMaster order by MachineId DESC "
        cur.execute(query)
        result = cur.fetchall()
        for res in result:
            results.append(res)
        return render_template('Dashboard.html',lpddis='none',pddis='none',oddis='none',dbtndis='none', ldbtndis='none',dbdis='none', Weight=0,dis='none', lvdisp='none', idis='none', lidis='none',mdis='inherit', sdis='none', lsdis='none',lmdis='inherit',odis='none',lodis='none', Machines=results)

@app.route('/showOrderConfig/<oid>',methods=['GET', 'POST'])
def showOrderConfig(oid):

    orderval=oid
    if orderval != "0":
        query = "delete from OrderConfig where OrderConfigId=" + orderval
        cur = myConnection.cursor()
        cur.execute(query)
        myConnection.commit();
        cur.close()
    query = "select o.OrderConfigId,i.ItemName,o.Quantity,v.VendorName,o.DefaultOrderQuantity from OrderConfig o, ItemMaster i , VendorMaster v where i.ItemId=o.ItemId and v.VendorId=o.VendorId order by OrderConfigId DESC "
    results = []
    cur = myConnection.cursor()
    cur.execute(query)
    result = cur.fetchall()
    for res in result:
        results.append(res)

    cur.close()
    queryitem = "select ItemId,ItemName from ItemMaster order by ItemName "
    resultsitem = []
    cur = myConnection.cursor()
    cur.execute(queryitem)
    resultitem = cur.fetchall()

    for res in resultitem:
        resultsitem.append(res)

    cur.close()

    queryvendor = "select VendorId,VendorName from VendorMaster order by VendorName "
    resultsvendor = []
    cur = myConnection.cursor()
    cur.execute(queryvendor)
    resultvendor = cur.fetchall()

    for res in resultvendor:
        resultsvendor.append(res)

    cur.close()
    return render_template('Dashboard.html',oddis='none',dbtndis='none', ldbtndis='none',dbdis='none',Weight=0, dis='none', lvdisp='none', idis='none', lidis='none', mdis='none',
                               lmdis='none', odis='inherit', lodis='none', sdis='none', lsdis='none',Orders=results, Items=resultsitem,
                               Vendors=resultsvendor,pddis='none',lpddis='none')

@app.route('/orderconfig', methods=['GET', 'POST'])
def orderconfig():
    if request.method == 'POST':
        results = []
        cur = myConnection.cursor()
        oid = request.form['txtOrderId']
        Itemid = int(request.form.get('selectItem'))
        Quantity = request.form['txtOrderQuantity']
        Vendorid = int(request.form.get('selectVendor'))
        OrderQuantity =int(request.form['txtDefaultOrderQuantity'])
        cur.callproc('sp_InsertOrderConfig', (oid, Itemid, Quantity, Vendorid,OrderQuantity))
        myConnection.commit()
        query = "select o.OrderConfigId,i.ItemName,o.Quantity,v.VendorName,o.DefaultOrderQuantity from OrderConfig o, ItemMaster i , VendorMaster v where i.ItemId=o.ItemId and v.VendorId=o.VendorId order by OrderConfigId Desc "
        cur.execute(query)
        result = cur.fetchall()
        for res in result:
            results.append(res)
        cur.close()
        queryitem = "select ItemId,ItemName from ItemMaster order by ItemName "
        resultsitem = []
        cur = myConnection.cursor()
        cur.execute(queryitem)
        resultitem = cur.fetchall()

        for res in resultitem:
            resultsitem.append(res)

        cur.close()

        queryvendor = "select VendorId,VendorName from VendorMaster order by VendorName "
        resultsvendor = []
        cur = myConnection.cursor()
        cur.execute(queryvendor)
        resultvendor = cur.fetchall()

        for res in resultvendor:
            resultsvendor.append(res)

        cur.close()
        return render_template('Dashboard.html',lpddis='none',pddis='none',oddis='none', dbtndis='none', ldbtndis='none',dbdis='none',Weight=0,dis='none', lvdisp='none', idis='none', lidis='none',
                               mdis='none', lmdis='none', odis='inherit', lodis='inherit',sdis='none', lsdis='none', Items=resultsitem,Vendors=resultsvendor,Orders=results)

@app.route('/showDashbuttonConfig/<dbid>', methods=['GET', 'POST'])
def showDashbuttonConfig(dbid):

        orderval = dbid
        if orderval != "0":
            query = "delete from DashConfig where DashConfigId=" + orderval
            cur = myConnection.cursor()
            cur.execute(query)
            myConnection.commit();
            cur.close()
        query = "select o.DashConfigId,i.ItemName,v.VendorName,o.DefaultOrderQuantity from DashConfig o, ItemMaster i , VendorMaster v where i.ItemId=o.ItemId and v.VendorId=o.VendorId order by DashConfigId DESC "
        results = []
        print '1'
        cur = myConnection.cursor()
        cur.execute(query)
        result = cur.fetchall()
        for res in result:
            results.append(res)

        cur.close()
        queryitem = "select ItemId,ItemName from ItemMaster order by ItemName "
        resultsitem = []
        cur = myConnection.cursor()
        cur.execute(queryitem)
        resultitem = cur.fetchall()

        for res in resultitem:
            resultsitem.append(res)

        cur.close()
        print '2'
        queryvendor = "select VendorId,VendorName from VendorMaster order by VendorName "
        resultsvendor = []
        cur = myConnection.cursor()
        cur.execute(queryvendor)
        resultvendor = cur.fetchall()

        for res in resultvendor:
            resultsvendor.append(res)

        cur.close()
        print '3'
        return render_template('Dashboard.html',lpddis='none',pddis='none', oddis='none',dbdis='none', Weight=0, dis='none', lvdisp='none', idis='none',
                               lidis='none', mdis='none',
                               lmdis='none', odis='none', lodis='none',dbtndis='inherit', ldbtndis='none', sdis='none', lsdis='none', DbOrders=results,
                               DbItems=resultsitem,
                               DbVendors=resultsvendor)
@app.route('/dashbuttonconfig', methods=['GET', 'POST'])
def dashbuttonconfig():
    if request.method == 'POST':
        results = []
        print '21'
        cur = myConnection.cursor()
        Itemid = int(request.form.get('selectdbItem'))
        Vendorid = int(request.form.get('selectdbVendor'))
        OrderQuantity = int(request.form['txtDefaultOrderQuantity'])
        print Itemid
        print Vendorid
        print OrderQuantity
        cur.callproc('sp_InsertDashbuttonConfig', (Itemid, Vendorid,OrderQuantity))
        myConnection.commit()
        print '1'
        query = "select o.DashConfigId,i.ItemName,v.VendorName,o.DefaultOrderQuantity from DashConfig o, ItemMaster i , VendorMaster v where i.ItemId=o.ItemId and v.VendorId=o.VendorId order by DashConfigId Desc "
        cur.execute(query)
        result = cur.fetchall()
        for res in result:
            results.append(res)
        cur.close()
        print '2'
        queryitem = "select ItemId,ItemName from ItemMaster order by ItemName "
        resultsitem = []
        cur = myConnection.cursor()
        cur.execute(queryitem)
        resultitem = cur.fetchall()

        for res in resultitem:
            resultsitem.append(res)

        cur.close()

        queryvendor = "select VendorId,VendorName from VendorMaster order by VendorName "
        resultsvendor = []
        cur = myConnection.cursor()
        cur.execute(queryvendor)
        resultvendor = cur.fetchall()

        for res in resultvendor:
            resultsvendor.append(res)

        cur.close()
        return render_template('Dashboard.html',lpddis='none',pddis='none',oddis='none', dbtndis='inherit', ldbtndis='inherit',dbdis='none',Weight=0,dis='none', lvdisp='none', idis='none', lidis='none',
                               mdis='none', lmdis='none', odis='none', lodis='none',sdis='none', lsdis='none', DbItems=resultsitem,DbVendors=resultsvendor,DbOrders=results)


@app.route('/showStockConfig/<sid>',methods=['GET', 'POST'])
def showStockConfig(sid):

    stockval=sid
    if stockval != "0":
        query = "delete from StockConfig where StockId=" + stockval
        cur = myConnection.cursor()
        cur.execute(query)
        myConnection.commit();
        cur.close()
    query = "select s.StockId,'MC1' as MachineCode, i.ItemCode,s.Quantity,s.TotalWeight from StockConfig s, ItemMaster i where s.ItemId=i.ItemId order by StockId desc "
    results = []
    cur = myConnection.cursor()
    cur.execute(query)
    result = cur.fetchall()
    for res in result:
        results.append(res)

    cur.close()
    queryweight = "select weight from weightlog where MachineId='MC1' and weight<>0 order by Id desc limit 1 "
    resultsitem = []
    cur = myConnection.cursor()
    cur.execute(queryweight)
    resultitem = cur.fetchall()

    for res in resultitem:
        resultsitem.append(res)
        wt=str(res[0])
    cur.close()

    return render_template('Dashboard.html',lpddis='none',pddis='none',oddis='none',dbtndis='none', ldbtndis='none',dbdis='none', dis='none', lvdisp='none', idis='none', lidis='none', mdis='none',
                               lmdis='none', odis='none', lodis='none',sdis='inherit', lsdis='none', Stocks=results, Weight=wt,
                               )

@app.route('/showDashboard',methods=['GET', 'POST'])
def Dashboard():
    resultsitem = []
    cur = myConnection.cursor()
    cur.callproc('sp_OrderCount')
    myConnection.commit()
    resultitem = cur.fetchall()
    for res in resultitem:
        resultsitem.append(res)
    neworders=resultsitem[0][0]
    recorders=resultsitem[1][0]
    autoorders=resultsitem[2][0]
    dashorders=resultsitem[3][0]

    return render_template('Dashboard.html',lpddis='none',pddis='none',oddis='none',dbtndis='none', ldbtndis='none',dbdis='inherit', dis='none', lvdisp='none', idis='none', lidis='none', mdis='none',
                               lmdis='none', odis='none', lodis='none',sdis='none', lsdis='none',  Weight=0,neworders=neworders,
    recorders=recorders, autoorders=autoorders,dashorders=dashorders)

@app.route('/showCount',methods=['GET', 'POST'])
def showCount():

    # cur = myConnection.cursor()
    # cur.callproc('sp_InsertOrder')
    # myConnection.commit()
    # cur.close()

    resultsitem = []
    cur = myConnection.cursor()
    cur.callproc('sp_OrderCount')
    myConnection.commit()
    print cur.rowcount
    resultitem = cur.fetchall()
    for res in resultitem:
        resultsitem.append(res)

    if cur.rowcount > 0:
        neworders=resultsitem[0][0]
        recorders=resultsitem[1][0]
        autoorders=resultsitem[2][0]
        dashorders=resultsitem[3][0]
        myjson = str(resultsitem[0][0]) + ',' + str(resultsitem[1][0]) + ',' + str(resultsitem[2][0]) + ',' + str(resultsitem[3][0])
    else:
        neworders = 0
        recorders = 0
        autoorders = 0
        dashorders = 0
        myjson="0,0,0,0"
    return myjson


@app.route('/stockconfig', methods=['GET', 'POST'])
def stockconfig():
    if request.method == 'POST':
        results = []
        cur = myConnection.cursor()
        Quantity = int(request.form['txtStockQuantity'])
        Totalwt = int(request.form['txtTotalWeight'])
        cur.callproc('sp_InsertStockConfig', ( Quantity, Totalwt))
        myConnection.commit()
        query = "select s.StockId,'MC1' as MachineCode, i.ItemCode,s.Quantity,s.TotalWeight from StockConfig s, ItemMaster i where s.ItemId=i.ItemId order by StockId desc "
        cur.execute(query)
        result = cur.fetchall()
        for res in result:
            results.append(res)
        cur.close()
        queryweight = "select weight from weightlog where MachineId='MC1' and weight<>0 order by Id desc limit 1 "
        resultsitem = []
        cur = myConnection.cursor()
        cur.execute(queryweight)
        resultitem = cur.fetchall()

        for res in resultitem:
            resultsitem.append(res)
            wt = str(res[0])
        cur.close()

        return render_template('Dashboard.html', lpddis='none',pddis='none',oddis='none',dbtndis='none', ldbtndis='none',dbdis='none',Weight=wt,dis='none', lvdisp='none', idis='none', lidis='none',
                               mdis='none', lmdis='none', odis='none', lodis='none',sdis='inherit', lsdis='inherit', Stocks=results)

@app.route('/showOrderdetails', methods=['GET', 'POST'])
def showOrderdetails():
    #if request.method == 'POST':
        querynew = "select o.MachineCode,o.ItemCode,i.ItemName,v.VendorName,o.Email,o.Phone,OrderQuantity,OrderStatus,OrderCreatedDate,'' as OrderReceivedDate,OrderFrom from OrderDetails o,VendorMaster v, ItemMaster i where o.ItemCode=i.Itemcode and o.VendorId=v.VendorId and o.OrderStatus='Pending'"
        resultsitem = []
        cur = myConnection.cursor()
        cur.execute(querynew)
        resultitem = cur.fetchall()

        for res in resultitem:
           resultsitem.append(res)
        cur.close()


        queryrec = "select o.MachineCode,o.ItemCode,i.ItemName,v.VendorName,o.Email,o.Phone,OrderQuantity,OrderStatus,OrderCreatedDate, OrderReceivedDate,OrderFrom from OrderDetails o,VendorMaster v, ItemMaster i where o.ItemCode=i.Itemcode and o.VendorId=v.VendorId and o.OrderStatus='Received'"
        resultsitemrec = []
        cur = myConnection.cursor()
        cur.execute(queryrec)
        resultitem = cur.fetchall()

        for res in resultitem:
            resultsitemrec.append(res)
        cur.close()


        queryauto = "select o.MachineCode,o.ItemCode,i.ItemName,v.VendorName,o.Email,o.Phone,OrderQuantity,OrderStatus,OrderCreatedDate,OrderReceivedDate,''as OrderFrom from OrderDetails o,VendorMaster v, ItemMaster i where o.ItemCode=i.Itemcode and o.VendorId=v.VendorId and o.OrderFrom='App'"
        resultsitemauto = []
        cur = myConnection.cursor()
        cur.execute(queryauto)
        resultitem = cur.fetchall()

        for res in resultitem:
            resultsitemauto.append(res)
        cur.close()


        querydash = "select o.MachineCode,o.ItemCode,i.ItemName,v.VendorName,o.Email,o.Phone,OrderQuantity,OrderStatus,OrderCreatedDate,OrderReceivedDate,''as OrderFrom from OrderDetails o,VendorMaster v, ItemMaster i where o.ItemCode=i.Itemcode and o.VendorId=v.VendorId and o.OrderFrom='Dash'"
        resultsitemdash = []
        cur = myConnection.cursor()
        cur.execute(querydash)
        resultitem = cur.fetchall()

        for res in resultitem:
            resultsitemdash.append(res)
        cur.close()

        return render_template('Dashboard.html',lpddis='none',pddis='none', dbtndis='none', ldbtndis='none',dbdis='none',Weight=0,dis='none', lvdisp='none', idis='none', lidis='none',
                               mdis='none', lmdis='none', odis='none', lodis='none',sdis='none', lsdis='none',
                               oddis='inherit', NewOrders=resultsitem, RecOrders=resultsitemrec,AutoOrders=resultsitemauto,DashOrders=resultsitemdash)


@app.route('/showPendingorders/<pid>',methods=['GET', 'POST'])
def showPendingorders(pid):

    orderval=pid
    timeo = time.strftime("%m.%d.%Y")
    if orderval != "0":
        query = "update OrderDetails set OrderStatus='Received',OrderReceivedDate='"+timeo+"' where OrderId=" + orderval
        print query
        cur = myConnection.cursor()
        cur.execute(query)
        myConnection.commit();
        cur.close()
    querynew = "select o.OrderId,o.ItemCode,i.ItemName,v.VendorName,o.Email,o.Phone,OrderQuantity,OrderStatus,OrderCreatedDate,'' as OrderReceivedDate,OrderFrom from OrderDetails o,VendorMaster v, ItemMaster i where o.ItemCode=i.Itemcode and o.VendorId=v.VendorId and o.OrderStatus='Pending'"
    resultsitem = []
    cur = myConnection.cursor()
    cur.execute(querynew)
    resultitem = cur.fetchall()

    for res in resultitem:
        resultsitem.append(res)
    cur.close()
    if orderval != "0":
        return render_template('Dashboard.html', oddis='none', dbtndis='none', ldbtndis='none', dbdis='none', Weight=0,
                               dis='none', lvdisp='none', idis='none', lidis='none', mdis='none',
                               lmdis='none', odis='none', lodis='none', sdis='none', lpddis='inherit', lsdis='none',
                               pddis='inherit', PenOrders=resultsitem)
    else:
        return render_template('Dashboard.html',oddis='none',dbtndis='none', ldbtndis='none',dbdis='none',Weight=0, dis='none', lvdisp='none', idis='none', lidis='none', mdis='none',
                               lmdis='none', odis='none', lodis='none', sdis='none',lpddis='none', lsdis='none',pddis='inherit',PenOrders=resultsitem)



if __name__ == '__main__':
    app.run(debug=True)
