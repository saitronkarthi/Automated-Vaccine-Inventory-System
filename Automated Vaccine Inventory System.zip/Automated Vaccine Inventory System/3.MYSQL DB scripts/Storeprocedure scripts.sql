
CREATE DEFINER=`karthik`@`%` PROCEDURE `login_check`(IN username varchar(100), IN pwd varchar(100))
BEGIN
select count(*) from user where email=username and upassword=pwd;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`karthik`@`%` PROCEDURE `sp_InsertAWSbtnlog`(
IN btnaddress varchar(100),
IN btnname varchar(100)
)
BEGIN
SET time_zone = 'US/Central';
insert into awsbtnlog(btnaddress,btnname,ltime,Status) values(btnaddress,btnname,now(),'New');
END$$
DELIMITER ;
DELIMITER $$
CREATE DEFINER=`karthik`@`%` PROCEDURE `sp_InsertDashbuttonConfig`(in Itemid int,in Vendorid int,in OrderQuantity int)
BEGIN


insert into DashConfig(ItemId,VendorId,MachineId,DefaultOrderQuantity) values
						(Itemid, Vendorid,1,OrderQuantity);

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`karthik`@`%` PROCEDURE `sp_InsertDashOrder`()
BEGIN
DECLARE DashId int;
DECLARE DefaultQuantity int;
DECLARE exit_loop BOOLEAN; 

   -- Declare the cursor
   
   Declare Dash_Cursor CURSOR for
      select id from awsbtnlog where Status='New' order by Id desc;
     OPEN Dash_cursor;
      Begin
   -- set exit_loop flag to true if there are no more rows
       DECLARE CONTINUE HANDLER FOR NOT FOUND SET exit_loop = TRUE;
   -- open the cursor
  
   -- start looping
   Dash_loop: LOOP
     -- read the name from next row into the variables 
     FETCH  Dash_Cursor INTO DashId;
     begin
     if(DashId!='') then
     insert into OrderDetails(MachineCode,ItemCode,VendorId,Email,Phone,
          OrderQuantity,OrderStatus,OrderCreatedDate,OrderFrom)
          select 'M1','V1',a.VendorId,b.Email,b.Phone,a.DefaultOrderQuantity,'New',
          now(),'Dash'
          from DashConfig a, VendorMaster b
          where a.VendorId=b.VendorId;
			UPDATE awsbtnlog 
			SET 
				Status = 'Old'
			WHERE
				Id = DashId; 
    end if;
     end;
     -- check if the exit_loop flag has been set by mysql, 
     -- close the cursor and exit the loop if it has.
     IF exit_loop THEN
         CLOSE Dash_cursor;
         LEAVE Dash_loop;
     END IF;
   END LOOP Dash_loop;
end;
   
END$$
DELIMITER ;
DELIMITER $$

CREATE DEFINER=`karthik`@`%` PROCEDURE `sp_InsertItem`(in iid varchar(5),in icode varchar(10), in iname varchar(50),in idesc varchar(300),in iunit varchar(20))
BEGIN
if(iid="0") then

insert into ItemMaster(Itemcode,Itemname,Itemdesc,Unit) values
						(icode, iname,idesc,iunit);
else
 update  ItemMaster set Itemcode=icode,Itemname=iname,Itemdesc=idesc,Unit=iunit where ItemId=iid;
 
end if;

END$$
DELIMITER ;


DELIMITER $$
CREATE DEFINER=`karthik`@`%` PROCEDURE `sp_InsertMachine`(in mid varchar(5),in mcode varchar(10),in mdesc varchar(300))
BEGIN
if(mid="0") then

insert into MachineMaster(Machinecode,Machinedesc) values
						(mcode, mdesc);
else
 update  MachineMaster set Machinecode=mcode,Machinedesc=mdesc where MachineId=mid;
 
end if;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`karthik`@`%` PROCEDURE `sp_InsertOrder`()
BEGIN

DECLARE DashId int;
DECLARE OrderVendorId int;
DECLARE OrderQuantity int;
DECLARE DefaultQuantity int;
declare current_streak int;
DECLARE exit_loop BOOLEAN; 
declare CurrentWeight int default 
(select weight from  weightlog where MachineId='MC1' and weight!=0  order by Id desc Limit 1);
declare weightId int default 
(select t.id from(select id from  weightlog where MachineId='MC1' and weight!=0 order by Id desc Limit 1)t);
declare IndividualWeight int default
(select IndividualWeight from StockConfig where ItemId=1 and MachineId=1 limit 1);
declare CurrentQuantity int default
(select  round(CurrentWeight/IndividualWeight));
declare Ordercount int default
(select WeightId from OrderDetails where WeightId=weightId limit 1);
 declare ocount int;
 
 DECLARE done INT DEFAULT FALSE;
  -- Declare the cursor
   DECLARE order_cursor CURSOR FOR
     SELECT VendorId, Quantity,DefaultOrderQuantity FROM OrderConfig;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE; 
    OPEN order_cursor;
               
     order_loop: LOOP
     FETCH  order_cursor INTO OrderVendorId, OrderQuantity,DefaultQuantity;
      IF done THEN
      LEAVE order_loop;
    END IF;
     if(CurrentWeight>=0) then
		 if(CurrentQuantity<=OrderQuantity) then
			  set @VMail=(select Email from VendorMaster where VendorId=OrderVendorId);
			  set @VPhone=(select Phone from VendorMaster where VendorId=OrderVendorId);
              insert into temp(mwt) values(Ordercount);
              select Ordercount;
             /* set Ordercount=(select count(*) from OrderDetails where WeightId=weightId);
              select Ordercount;*/
              if(Ordercount=0) then
			  insert into OrderDetails(MachineCode,ItemCode,VendorId,Email,Phone,
			  OrderQuantity,OrderStatus,OrderCreatedDate,OrderFrom,WeightId)
			  values('MC1','V1',OrderVendorId,@VMail,@VPhone,DefaultQuantity,'New',
			  now(),'App',weightId); 
              update weightlog set Status='Old' where id=weightId;
			end if;
             end if;
			
	end if;
    
     -- check if the exit_loop flag has been set by mysql, 
     -- close the cursor and exit the loop if it has.
    
   END LOOP;
   close order_cursor;
   
END$$
DELIMITER ;
DELIMITER $$
CREATE DEFINER=`karthik`@`%` PROCEDURE `sp_InsertOrderConfig`(in oid varchar(5),in Itemid int,in Quantity varchar(5),in Vendorid int,in OrderQuantity int)
BEGIN
if(oid="0") then

insert into OrderConfig(ItemId,Quantity,VendorId,MachineId,DefaultOrderQuantity) values
						(Itemid, Quantity,Vendorid,1,OrderQuantity);
else
 update  OrderConfig set ItemId=Itemid,Quantity=Quantity,VendorId=Vendorid,DefaultOrderQuantity=OrderQuantity where OrderConfigId=oid;
 
end if;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`karthik`@`%` PROCEDURE `sp_InsertStockConfig`(in Quantity int,in TotalWeight int)
BEGIN

set @Inweight=round(TotalWeight/Quantity);
insert into StockConfig(ItemId,MachineId,Quantity,TotalWeight,IndividualWeight)
values(1,1,Quantity,TotalWeight,@Inweight);

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`karthik`@`%` PROCEDURE `sp_InsertVendor`(in vid varchar(5),in vcode varchar(10), in vname varchar(50),
                                  in address varchar(300), in email varchar(30), in phone varchar(15))
BEGIN
if(vid="0") then

insert into VendorMaster(Vendorcode,Vendorname,Address,Email,Phone) values
						(vcode, vname,address,email,phone);
else
 update  VendorMaster set Vendorcode=vcode,Vendorname=vname,Address=address,Email=email,Phone=phone where VendorId=vid;
 

end if;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`karthik`@`%` PROCEDURE `sp_InsertWeightlog`(
 IN lweight int,
 IN t varchar(100), 
 IN mc varchar(100)
 )
BEGIN
declare a int;
 declare b int;
 
 
declare CurrentWeight int default 
(select weight from  weightlog where MachineId='MC1' and weight!=0 order by Id desc Limit 1);
 SET time_zone = 'US/Central';
  if (CurrentWeight is null) then
    set CurrentWeight=0;
 end if;

 set a=CurrentWeight;
 set b= lweight;
if(round(a)-round(b) >50) then
begin
 if(lweight>350) then
  insert into weightlog(weight,ltime,machineid,Status) values(lweight,now(),mc,'Old');
  else
  insert into weightlog(weight,ltime,machineid,Status) values(lweight,now(),mc,'New');
  end if;
 end;
  
end if;

if(round(b) -round(a) >50) then
if(lweight>350) then
  insert into weightlog(weight,ltime,machineid,Status) values(lweight,now(),mc,'Old');
  else
  insert into weightlog(weight,ltime,machineid,Status) values(lweight,now(),mc,'New');
  end if;
end if;

 END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`karthik`@`%` PROCEDURE `sp_OrderCount`()
BEGIN
select count(*) as Count from OrderDetails where OrderStatus='Pending'
union all
select count(*) as Count from OrderDetails where OrderStatus='Received'
union all
select count(*) as Count from OrderDetails where OrderFrom='App'
union all
select count(*) as Count from OrderDetails where OrderFrom='Dash';
END$$
DELIMITER ;








