CREATE TABLE `awsbtnlog` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `btnaddress` varchar(100) DEFAULT NULL,
  `btnname` varchar(100) DEFAULT NULL,
  `ltime` varchar(100) DEFAULT NULL,
  `Status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=latin1;

CREATE TABLE `DashConfig` (
  `DashConfigId` int(11) NOT NULL AUTO_INCREMENT,
  `ItemId` int(11) DEFAULT NULL,
  `VendorId` int(11) DEFAULT NULL,
  `MachineId` int(11) DEFAULT NULL,
  `DefaultOrderQuantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`DashConfigId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
CREATE TABLE `ItemMaster` (
  `ItemId` int(11) NOT NULL AUTO_INCREMENT,
  `Itemcode` varchar(10) DEFAULT NULL,
  `Itemname` varchar(50) DEFAULT NULL,
  `Itemdesc` varchar(300) DEFAULT NULL,
  `Unit` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ItemId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

CREATE TABLE `MachineMaster` (
  `MachineId` int(11) NOT NULL AUTO_INCREMENT,
  `Machinecode` varchar(10) DEFAULT NULL,
  `Machinedesc` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`MachineId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
CREATE TABLE `OrderConfig` (
  `OrderConfigId` int(11) NOT NULL AUTO_INCREMENT,
  `ItemId` int(11) DEFAULT NULL,
  `Quantity` varchar(5) DEFAULT NULL,
  `VendorId` int(11) DEFAULT NULL,
  `MachineId` int(11) DEFAULT '1',
  `DefaultOrderQuantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`OrderConfigId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
CREATE TABLE `OrderDetails` (
  `OrderId` int(11) NOT NULL AUTO_INCREMENT,
  `MachineCode` varchar(5) DEFAULT NULL,
  `ItemCode` varchar(5) DEFAULT NULL,
  `VendorId` int(11) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `Phone` varchar(15) DEFAULT NULL,
  `OrderQuantity` int(11) DEFAULT NULL,
  `OrderStatus` varchar(10) DEFAULT NULL,
  `OrderCreatedDate` varchar(25) DEFAULT NULL,
  `OrderReceivedDate` varchar(25) DEFAULT NULL,
  `OrderFrom` varchar(10) DEFAULT NULL,
  `WeightId` int(11) DEFAULT NULL,
  PRIMARY KEY (`OrderId`)
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=latin1;

CREATE TABLE `StockConfig` (
  `StockId` int(11) NOT NULL AUTO_INCREMENT,
  `ItemId` int(11) DEFAULT NULL,
  `MachineId` int(11) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `TotalWeight` int(11) DEFAULT NULL,
  `IndividualWeight` int(11) DEFAULT NULL,
  PRIMARY KEY (`StockId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

CREATE TABLE `user` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `upassword` varchar(100) NOT NULL,
  `ustatus` varchar(5) NOT NULL,
  `createdon` varchar(100) NOT NULL,
  `modifiedon` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

CREATE TABLE `VendorMaster` (
  `VendorId` int(11) NOT NULL AUTO_INCREMENT,
  `Vendorcode` varchar(10) DEFAULT NULL,
  `Vendorname` varchar(50) DEFAULT NULL,
  `Address` varchar(300) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `Phone` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`VendorId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

CREATE TABLE `weightlog` (
  `weight` int(11) DEFAULT NULL,
  `ltime` varchar(100) DEFAULT NULL,
  `machineid` varchar(100) DEFAULT NULL,
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `Status` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=latin1;






