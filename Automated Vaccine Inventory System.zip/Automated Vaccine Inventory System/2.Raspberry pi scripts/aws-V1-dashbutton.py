from scapy.all import *
import pymysql
hostname = 'xxx'
username = 'xxx'
password = 'xxx'
database = 'xxx'
myConnection1 = pymysql.connect( host=hostname, user=username, passwd=password, db=database )
cur = myConnection1.cursor()
btnid='AWS-V1-dashbutton'#Machine Id

def arp_display(pkt):
 if pkt.haslayer(ARP):
  if pkt[ARP].op == 1: #who-has (request)
    if pkt[ARP].psrc == '0.0.0.0': # ARP Probe
        if pkt[ARP].hwsrc == 'f0:27:2d:67:07:57': # Amazon Dash-Tide
          print "Pushed Tide Button"
          print "ARP Probe from: " + pkt[ARP].hwsrc
          cur.callproc('sp_InsertAWSbtnlog',(pkt[ARP].hwsrc,btnid))
          myConnection1.commit()
          print "Inserted in to sql"

print sniff(prn=arp_display, filter="arp", store=0)



