from flask import Flask,render_template,request,json,jsonify
from twilio.rest import TwilioRestClient
from email.mime.text import MIMEText
import pymysql
import smtplib
import time
import string

hostname = 'xxxx'
username = 'xxxx'
password = 'xxxx'
database = 'VaccineInventory'

while True:
 results = []
 myConnection = pymysql.connect(host=hostname, user=username, passwd=password, db=database)
 cur = myConnection.cursor()
 query = "select id,weight from weightlog where Status='New' order by Id desc"
 cur.execute(query)
 print query
 result = cur.fetchall()
 for res in result:
    results.append(res)
    if cur.rowcount>0:
        print cur.rowcount
        weightid=str(res[0])
        curweight=int(str(res[1]))
        quertinwt="select IndividualWeight from StockConfig where ItemId=1 and MachineId=1 limit 1"
        cur.execute(quertinwt)
        result = cur.fetchall()
        for res in result:
            results.append(res)
        quantity=(int(curweight)/int(res[0]))
        results = []
        query="SELECT VendorId, Quantity,DefaultOrderQuantity FROM OrderConfig"
        cur.execute(query)
        result = cur.fetchall()
        for res in result:
            results.append(res)
            stockquan=int(res[1])
            vid=str(res[0])
            orderq=str(res[2])
            query="select Email,Phone from VendorMaster where VendorId="+vid
            cur.execute(query)
            result = cur.fetchall()
            for res in result:
              results.append(res)
              email=str(res[0])
              phone=str(res[1])
              timeo = time.strftime("%m.%d.%Y")
              if quantity<=stockquan:
                  query="insert into OrderDetails(MachineCode,ItemCode,VendorId,Email,Phone,OrderQuantity,OrderStatus,OrderCreatedDate,OrderFrom)values('MC1','V1','"+vid+"','"+email+"','"+phone+"','"+orderq+"','New','"+timeo+"','App')"

                  cur.execute(query)
                  myConnection.commit()
                  queryup="update weightlog set Status='Old'"
                  cur.execute(queryup)
                  myConnection.commit()

                  query = "select a.Email,a.Phone,b.VendorName,a.OrderQuantity,a.OrderId from OrderDetails a, VendorMaster b where a.OrderStatus='New' and OrderFrom='App' and a.VendorId=b.VendorId order by a.OrderId DESC "
                  print query
                  cur.execute(query)

                  results=[]
                  result=cur.fetchall()
                  myConnection.commit()
                  for res in result:
                            results.append(res)
                            if cur.rowcount>0:
                                server = smtplib.SMTP('smtp.gmail.com', 587)
                                server.starttls()
                                server.login("emailid@gmail.com", "pwd")
                                email=str(res[0])
                                Phone=str(res[1])
                                Name=str(res[2])
                                Quantity=str(res[3])
                                OrderId=str(res[4])
                                Subject = "Order Details"
                                timeo = time.strftime("%m.%d.%Y")
                                subject = "Order Details"
                                body = string.join((
                                    "Subject %s" %Subject,
                                    "",
                                    "Dear %s" % Name,
                                    "",
                                    "Please find your automated order details below from Vaccine Ordering System.",
                                    "",
                                    "ItemCode : V1",
                                    "Quantity : %s" % Quantity,
                                    "Order Date :%s" % timeo,
                                    "",
                                    "Kindly ship the orders to us.",
                                    "Thank you!"
                                ), "\r\n")
                                print body
                                server.sendmail("admin@autovaccine.com", email, body)
                                server.quit()
                                account_sid = "xxx"
                                auth_token = "xxx"
                                client = TwilioRestClient(account_sid, auth_token)

                                message = client.messages.create(to=Phone, from_="+xxx", body="Hello! A new Automated Order from Vaccine Inventory for Item Code : V1 has been placed. Please check your email for details!")
                                orderupdateqry="update OrderDetails set OrderStatus='Pending' where OrderId= "+OrderId
                                cur.execute(orderupdateqry)
                                myConnection.commit()
 cur.close()
 myConnection.close()
 time.sleep(5)
