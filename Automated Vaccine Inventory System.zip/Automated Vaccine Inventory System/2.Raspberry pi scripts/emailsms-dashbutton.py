from flask import Flask,render_template,request,json,jsonify
from twilio.rest import TwilioRestClient
from email.mime.text import MIMEText
import pymysql
import smtplib
import time
import string

hostname = 'xxx'
username = 'xxx'
password = 'xxx'
database = 'xxx'


while True:
    results = []
    myConnection = pymysql.connect(host=hostname, user=username, passwd=password, db=database)
    cur = myConnection.cursor()
    querydash = "select id from awsbtnlog where Status='New' order by Id desc"
    print querydash
    cur.execute(querydash)
    result = cur.fetchall()
    print result
    for res in result:
        results.append(res)
        dashid = str(res[0])
        print cur.rowcount
        if (cur.rowcount > 0):
            query = "SELECT VendorId,DefaultOrderQuantity,DashConfigId FROM DashConfig order by DashConfigId desc"
            print query
            cur.execute(query)
            result = cur.fetchall()
            for res in result:
                results = []
                results.append(res)
                venid = str(res[0])
                orderdq = str(res[1])
                print results
                print 'Did' + dashid
                query = "select Email,Phone from VendorMaster where VendorId=" + venid
                cur.execute(query)
                result = cur.fetchall()
                for res in result:
                    results.append(res)
                    vemail = str(res[0])
                    vphone = str(res[1])
                    vtimeo = time.strftime("%m.%d.%Y")
                    query = "insert into OrderDetails(MachineCode,ItemCode,VendorId,Email,Phone,OrderQuantity,OrderStatus,OrderCreatedDate,OrderFrom)values('MC1','V1','" + venid + "','" + vemail + "','" + vphone + "','" + orderdq + "','New','" + vtimeo + "','Dash')"

                    cur.execute(query)
                    myConnection.commit()
                    queryup = "update awsbtnlog set Status='Old' where id=" + dashid
                    cur.execute(queryup)
                    myConnection.commit()

                    query = "select a.Email,a.Phone,b.VendorName,a.OrderQuantity,a.OrderId from OrderDetails a, VendorMaster b where a.OrderStatus='New' and OrderFrom='Dash' and a.VendorId=b.VendorId order by a.OrderId DESC "
                    print query
                    cur.execute(query)
                    print cur.rowcount
                    results = []
                    result = cur.fetchall()
                    myConnection.commit()
                    for res in result:
                        results.append(res)
                        print cur.rowcount
                        if cur.rowcount > 0:
                            server = smtplib.SMTP('smtp.gmail.com', 587)
                            server.starttls()
                            server.login("emailid", "pwd")
                            email = str(res[0])
                            Phone = str(res[1])
                            Name = str(res[2])
                            Quantity = str(res[3])
                            OrderId = str(res[4])
                            Subject = "Order Details"
                            timeo = time.strftime("%m.%d.%Y")
                            subject = "Order Details"
                            body = string.join((
                                "Subject : %s " % Subject,
                                "",
                                "Dear %s" % Name,
                                "",
                                "Please find your order details below from Dash Button.",
                                "",
                                "ItemCode : V1",
                                "Quantity : %s" % Quantity,
                                "Order Date :%s" % timeo,
                                "",
                                "Kindly ship the orders to us.",
                                "Thank you!"
                            ), "\r\n")
                            print body
                            server.sendmail("admin@autovaccine.com", email, body)
                            server.quit()
                            account_sid = "xxx"
                            auth_token = "xxx"
                            client = TwilioRestClient(account_sid, auth_token)

                            message = client.messages.create(to=Phone, from_="+twiliono",
                                                             body="Hello! A new Order from Dash Button for Item Code : V1 has been placed. Please check your email for details!")
                            orderupdateqry = "update OrderDetails set OrderStatus='Pending' where OrderId= " + OrderId
                            cur = myConnection.cursor()
                            cur.execute(orderupdateqry)
                            myConnection.commit()
                            cur.close()
                            myConnection.close()
    time.sleep(5)
